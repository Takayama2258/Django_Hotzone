function searchLocation(current_all){
    var q = document.getElementById("q").value;

    if (q == ""){
        alert("Location name cannot be empty. Please enter a location name!");
        return;
    }

    var locations = document.getElementById("locationresults");
    locations.innerHTML = '';

    // adding <th> line
    var thr = document.createElement("tr");

    var select = document.createTextNode("Select");
    var sh = document.createElement("th");
    sh.appendChild(select);
    var locname = document.createTextNode("Location Name");
    var nh = document.createElement("th");
    nh.appendChild(locname);
    var adt = document.createTextNode("Address");
    var adh = document.createElement("th");
    adh.appendChild(adt);
    var xtt = document.createTextNode("X Coord");
    var xth = document.createElement("th");
    xth.appendChild(xtt);
    var ytt = document.createTextNode("Y Coord");
    var yth = document.createElement("th");
    yth.appendChild(ytt);

    thr.appendChild(sh);
    thr.appendChild(nh);
    thr.appendChild(adh);
    thr.appendChild(xth);
    thr.appendChild(yth);
    locations.appendChild(thr);

    // check in current database
    var all = JSON.parse(current_all);
    if (all.length > 0){
        var db_name = [all[0].fields.location_name];
        var db_address = [all[0].fields.address];
        var db_x = [all[0].fields.x_coord];
        var db_y = [all[0].fields.y_coord];
    }
    if (all.length > 1){
        for (var i = 1; i < all.length; i++){
            db_name.push(all[i].fields.location_name);
            db_address.push(all[i].fields.address);
            db_x.push(all[i].fields.x_coord);
            db_y.push(all[i].fields.y_coord);
        }
    }
    var existing, count = 0;
    // check whether any location_name contains q
    if (all.length > 0){
        for (var j = 0; j < all.length; j++){
            var name_lower = db_name[j].toLowerCase();
            var q_lower = q.toLowerCase();
            if (name_lower.includes(q_lower)){
                var tr = document.createElement("tr");
                tr.style.color = "tomato";
                var _radio = document.createElement("input");
                _radio.type = "radio";
                _radio.name = "location";
                var shown_name = "[Existing location] "+db_name[j];
                var name = db_name[j];
                var ad = db_address[j];
                var x = db_x[j];
                var y = db_y[j];
                _radio.value = name +"+" + ad + "+" +x + "+" +y;

                if (ad == "---")
                    _radio.value = name +"++" +x + "+" +y;
                if (count == 0)
                    existing = [_radio.value];
                else
                    existing.push(_radio.value);
                count++;
                _radio.value = name +"+" + ad + "+" +x + "+" +y;

                var rd = document.createElement("td");
                rd.appendChild(_radio);
                tr.appendChild(rd);
                var nd = document.createElement("td");
                var nt = document.createTextNode(shown_name);
                nd.appendChild(nt);
                tr.appendChild(nd);
                var add = document.createElement("td");
                var at = document.createTextNode(ad);
                add.appendChild(at);
                tr.appendChild(add);
                var xd = document.createElement("td");
                var xt = document.createTextNode(x);
                xd.appendChild(xt);
                tr.appendChild(xd);
                var yd = document.createElement("td");
                var yt = document.createTextNode(y);
                yd.appendChild(yt);
                tr.appendChild(yd);

                locations.appendChild(tr);
            }
        }
    }

    // check in GeoData
    var url = 'https://geodata.gov.hk/gs/api/v1.0.0/locationSearch?q='+q;

    fetch(url, {method: 'GET'}).then(response => {

        if (response.status == 200){
            response.json().then( result => {
                if (result.length == 0){
                    alert("Oops! This location does not exist in the Hong Kong Government Geodata Store datasets. Please try another location name!");
                    location.reload();
                    return;
                }

                for(i = 0; i < result.length; i++){
                    var tr = document.createElement("tr");
                    var _radio = document.createElement("input");
                    _radio.type = "radio";
                    _radio.name = "location";
                    var name = result[i].nameEN;
                    var ad = result[i].addressEN;
                    var x =result[i].x;
                    var y = result[i].y;
                    _radio.value = name +"+" + ad + "+" +x + "+" +y;
                    var repeat = false;

                    if (count > 0)
                        for (var k = 0; k < existing.length; k++){
                            if (existing[k] == _radio.value){
                                repeat = true;
                            }
                        }

                    if (repeat)
                        continue;

                    var rd = document.createElement("td");
                    rd.appendChild(_radio);
                    tr.appendChild(rd);
                    var nd = document.createElement("td");
                    var nt = document.createTextNode(name);
                    nd.appendChild(nt);
                    tr.appendChild(nd);
                    var add = document.createElement("td");
                    var at = document.createTextNode(ad);
                    add.appendChild(at);
                    tr.appendChild(add);
                    var xd = document.createElement("td");
                    var xt = document.createTextNode(x);
                    xd.appendChild(xt);
                    tr.appendChild(xd);
                    var yd = document.createElement("td");
                    var yt = document.createTextNode(y);
                    yd.appendChild(yt);
                    tr.appendChild(yd);

                    locations.appendChild(tr);
                    console.log(_radio);
            }


		})
        }
        else{
            alert("HTTP response is not successful!");
        }
    })
}


function selectLocation(){
    var item = null;
    var s = document.getElementsByName("location");
    var selected = false;
    for (var i = 0; i < s.length; i++) {
        if (s[i].checked) {
            selected = true;
            item = s[i].value;
            var attr = item.split("+");
            var n=attr[0];
            var a=attr[1];
            var x=attr[2];
            var y=attr[3];
            console.log(n);
            if (x.length == 0 || y.length == 0){
                alert("The X/Y Coordinate of the location cannot be empty. Please select another location!");
                return false;
            }
            else if (n.length == 0){
                alert("The location name cannot be empty. Please select another location!");
                return false;
            }
            else{
                return true;
            }
        }
    }
    return true;
}

function caseSearch(){
    console.log("entering caseSearch function in js");
    window.location.href = '/search';
}

window.onload = function emptySelection(){
    if (document.getElementById("empty")){
        alert("No location is selected! Please select a location first.");
    }
}

function stopRKey(evt) {
  var evt = (evt) ? evt : ((event) ? event : null);
  var node = (evt.target) ? evt.target : ((evt.srcElement) ? evt.srcElement : null);
  if ((evt.keyCode == 13) && (node.type=="text"))  {return false;}
}

document.onkeypress = stopRKey;

function caseNumValidation(total){
    var x = document.getElementById("casenum").value;
    console.log(x);
    if (x <= 0 || x > total){
        alert("Case number is out of range. Please input again!");
        return false;
    }
    else if (isNaN(x)){
        alert("Case number should be a number. Please input again!");
        return false;
    }
    else if (!Number.isInteger(Number(x))){
        alert("Case number should be an integer. Please input again!");
        return false;
    }
    else
        return true;
}

function dateValidation(){
    var dfrom = document.getElementById("date_from").value;
    var dto = document.getElementById("date_to").value;
    if (dfrom <= dto)
        return true;
    else{
        alert("Starting date should be no later than ending date. Please input again!");
        return false;
    }
}

function stopRKey(evt) {
  var evt = (evt) ? evt : ((event) ? event : null);
  var node = (evt.target) ? evt.target : ((evt.srcElement) ? evt.srcElement : null);
  if ((evt.keyCode == 13) && (node.type=="text"))  {return false;}
}

document.onkeypress = stopRKey;

function caseSearch(){
    window.location.href = '/search';
}
  
function locationSearch(){
    window.location.href = '/search/locationsearch/';
}

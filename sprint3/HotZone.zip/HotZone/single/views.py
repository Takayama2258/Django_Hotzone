from django.shortcuts import render, redirect
from django.http import HttpResponse
from single.models import Case, Location, Patient, Infecting_Virus, VisitDetail
from django.views.generic import TemplateView, ListView
from django.forms import ModelForm
from django.core.exceptions import ObjectDoesNotExist
from django.core import serializers
from json import dumps

import numpy as np
from sklearn.cluster import DBSCAN
import math
from datetime import date

import logging
logger = logging.getLogger(__name__)

def custom_metric(q, p, space_eps, time_eps): #this is for clustering
    dist = 0
    for i in range(2):
        dist += (q[i] - p[i])**2
    spatial_dist = math.sqrt(dist)

    time_dist = math.sqrt((q[2]-p[2])**2)

    if time_dist/time_eps <= 1 and spatial_dist/space_eps <= 1 and p[3] != q[3]:
        return 1
    else:
        return 2


def cluster(vector_4d, distance, time, minimum_cluster): #this is for clustering

    params = {"space_eps": distance, "time_eps": time}
    db = DBSCAN(eps=1, min_samples=minimum_cluster-1, metric=custom_metric, metric_params=params).fit_predict(vector_4d)

    unique_labels = set(db)
    total_clusters = len(unique_labels) if -1 not in unique_labels else len(unique_labels) -1

    #print("Total clusters:", total_clusters)

    #total_noise = list(db).count(-1)

    #print("Total un-clustered:", total_noise)
    result=[]

    for k in unique_labels:
        if k != -1:

            labels_k = db == k
            cluster_k = vector_4d[labels_k]

            #print("Cluster", k, " size:", len(cluster_k))
            cluster_record=[]
            for pt in cluster_k:
                visit_record={"x":pt[0],"y":pt[1],"day":pt[2],"caseNo":pt[3]}
                cluster_record.append(visit_record)
                #print("(x:{}, y:{}, day:{}, caseNo:{})".format(pt[0], pt[1], pt[2], pt[3]))

            result.append(cluster_record)


    return result

def authentication(request):
    return redirect('/accounts/login/')

def menu(request):
    return render(request, "menu.html")

def clustering(request):
    return render(request, "clustering.html")

def clusteringResult(request):
    D=int(request.GET['D'])
    T=int(request.GET['T'])
    C=int(request.GET['C'])

    visitArray = []
    original = date(2020,1,1)
    #prepare a vector_4d v4 for clustering
    cases = Case.objects.all()
    for case in cases:
        casenum = case.case_number
        visits = case.visit_detail.all()
        for visit in visits:
            if visit.date_from == visit.date_to and visit.category == "visit":
                date_from = visit.date_from
                day = (date_from - original).days
                x_coord = visit.location.x_coord
                y_coord = visit.location.y_coord
                record = [x_coord, y_coord, day, casenum]
                visitArray.append(record)

    npArray = np.array(visitArray)
    for record in visitArray:
        logger.error(record[0])
   

    params = {"space_eps": D, "time_eps": T}
    db = DBSCAN(eps=1, min_samples=C-1, metric=custom_metric, metric_params=params).fit_predict(npArray)

    unique_labels = set(db)
    total_clusters = len(unique_labels) if -1 not in unique_labels else len(unique_labels) -1

    #print("Total clusters:", total_clusters)

    #total_noise = list(db).count(-1)

    #print("Total un-clustered:", total_noise)
    result=[]

    for k in unique_labels:
        if k != -1:

            labels_k = db == k
            cluster_k = npArray[labels_k]

            #print("Cluster", k, " size:", len(cluster_k))
            cluster_record=[]
            for pt in cluster_k:
                visit_record={"x":pt[0],"y":pt[1],"day":pt[2],"caseNo":pt[3]}
                cluster_record.append(visit_record)
                #print("(x:{}, y:{}, day:{}, caseNo:{})".format(pt[0], pt[1], pt[2], pt[3]))

            result.append(cluster_record)




    result_format=[
        [
            {"location":"","x":812345,"y":812345,"day":1,"caseNo":11},
            {"location":"","x":812345,"y":812345,"day":1,"caseNo":12}
        ],
        [
            {"location":"","x":812345,"y":812345,"day":2,"caseNo":22}
        ]
    ] #just for reference

    for cluster in result:
        for visit in cluster:
            x=visit["x"]
            y=visit["y"]
            location=Location.objects.get(x_coord=x, y_coord=y)
            visit["location"]=location.location_name

    return render(request, "clustering_result.html", {'result': result})

def caseSearch(request):
    total_case = Case.objects.count()
    return render(request, "case_search.html", {'total': total_case})

def caseInfo(request):
    number = int(request.GET['casenum'])
    case_obj = Case.objects.get(case_number=number)
    request.session['case']=number
    return render(request, "case_info.html", {'case': case_obj})

def addLocation(request):
    try: #if "return" button is selected
        return_to_search = request.GET['return']
        total_case = Case.objects.count()
        return render(request, "case_search.html", {'total': total_case})
    except:
        try: #if a location is selected as expected
            temp=request.GET['location']
            query = request.GET['query']
        except: # if "create" button is pressed without selecting a location
            all_locations = serializers.serialize("json", Location.objects.all())
            locationsJSON = dumps(all_locations)
            empty_selection = True
            query = request.GET['query']
            context = {
                'locations': locationsJSON,
                'empty_selection': empty_selection,
                'query': query,
            }
            return render(request, "find_locations.html", context)
        location_detail=temp.split("+")
        name=location_detail[0]
        address=location_detail[1]
        if not address:
            address="---"
        x=location_detail[2]
        y=location_detail[3]

        request.session['location']=name   #save location detail as session variables
        request.session['location_x']=x
        request.session['location_y']=y
        request.session['address']=address
        request.session['query']=query

        context = {
            'location': name,
            'case': request.session['case'],
        }
        return render(request, "location_complete.html", context)

def locationSearch(request):
    all_locations = serializers.serialize("json", Location.objects.all())
    locationsJSON = dumps(all_locations)
    empty_selection = False
    context = {
        'locations': locationsJSON,
        'empty_selection': empty_selection,
    }
    return render(request, "find_locations.html", context)

def locationcomplete(request):
    try: # if return button is pressed
        returnloc = request.GET['returnloc']
        query=request.session.get('query')
        all_locations = serializers.serialize("json", Location.objects.all())
        locationsJSON = dumps(all_locations)
        return_complete = True
        context = {
            'locations': locationsJSON,
            'return_complete': return_complete,
            'query': query,
        }
        return render(request, "find_locations.html", context)
    except:
        date_from = request.GET['from']
        date_to = request.GET['to']
        category = request.GET['category']

        visit_detail = VisitDetail.objects.create() #create a visit_detail in database
        visit_detail.date_from=date_from
        visit_detail.date_to=date_to
        visit_detail.category=category

        name=request.session.get('location') #set the foreign key (location) of visit_detail to be the location just searched
        x=request.session.get('location_x')
        y=request.session.get('location_y')
        address=request.session.get('address')
        try:
            location_obj = Location.objects.get(location_name=name, x_coord=x, y_coord=y)
        except ObjectDoesNotExist: #create location if it does not exist in database
            location_obj = Location.objects.create()
            # modify the data
            location_obj.location_name = name
            location_obj.address = address
            location_obj.x_coord = x
            location_obj.y_coord = y
            # save location_obj
            location_obj.save()

        visit_detail.location=location_obj
        visit_detail.save()

        number=request.session.get('case')  #add the visit_detail to the case
        case_obj = Case.objects.get(case_number=number)
        case_obj.visit_detail.add(visit_detail)
        return render(request, "case_info.html", {'case': case_obj})

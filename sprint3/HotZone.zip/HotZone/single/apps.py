#Nothing edited in this file-20201105 v.0

from django.apps import AppConfig

#The app name is 'single'
class SingleConfig(AppConfig):
    name = 'single'

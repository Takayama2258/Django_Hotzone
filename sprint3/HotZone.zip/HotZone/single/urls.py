from django.urls import path
from . import views
from django.conf.urls import include, url

urlpatterns = [
    path('', views.authentication, name='authentication'),
    path('menu/', views.menu, name='menu'),
    path('clustering/', views.clustering, name='clustering'),
    path('clustering/result', views.clusteringResult, name='clustering/result'),
    path('search/', views.caseSearch, name='search'),
    path('search/caseinfo/', views.caseInfo, name='search/caseinfo'),
    path('search/locationsearch/', views.locationSearch, name='locationSearch'),
    path('search/addlocation/',views.addLocation, name='search/addlocation'),
    path('search/locationcomplete', views.locationcomplete, name='search/locationcomplete'),
    path('accounts/', include('django.contrib.auth.urls')),

]

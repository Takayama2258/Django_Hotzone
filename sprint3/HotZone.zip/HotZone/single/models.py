from django.db import models


# The initial location address, x_coord, and y_coord should be NULL when user add the location to the record (i.e. before search)

class Location(models.Model):
	location_name = models.CharField(max_length=200)
	address = models.CharField(max_length=300, blank=True, null=True)
	x_coord = models.FloatField(blank=True, null=True)
	y_coord = models.FloatField(blank=True, null=True)
	def __str__(self):
		return self.location_name

class Patient(models.Model):
	patient_name = models.CharField(max_length=200)
	identity_document_number = models.CharField(max_length=10)
	date_of_birth = models.DateField(blank=True, null=True)
	def __str__(self):
		return self.patient_name

class Infecting_Virus(models.Model):
	virus_name = models.CharField(max_length=100)
	disease_name = models.CharField(max_length=100)
	max_infectious_period = models.PositiveSmallIntegerField(blank=True, null=True)
	def __str__(self):
		return self.virus_name

class VisitDetail(models.Model):
	date_from = models.DateField(blank=True, null=True)
	date_to = models.DateField(blank=True, null=True)
	category = models.CharField(max_length=9, blank=True, null=True)
	location = models.ForeignKey(Location, on_delete=models.CASCADE,blank=True, null=True)
	#A VisitDetail can only have one location

# "patient", "infecting_virus", and "locations" are foreign keys reference to class Patient, Infecting_Virus, Location, accordingly. "locations" is a many-to-many mapping between Case and Location (i.e. a case can have multiple locations && a location can have multiple related cases)
class Case(models.Model):
	case_number = models.PositiveIntegerField()
	date_confirmed = models.DateField()
	local_or_imported = models.CharField(max_length=8)
	patient = models.ForeignKey(Patient, on_delete=models.CASCADE)
	infecting_virus = models.ForeignKey(Infecting_Virus, on_delete=models.CASCADE)
	visit_detail = models.ManyToManyField(VisitDetail, blank=True, null=True)
	#A case can have many visits (i.e. VisitDetail)

from django.contrib import admin
from .models import *

# Register your models here.

# below includes the classes (i.e. Case, Location, Patient, Infecting_Virus) in models.py
admin.site.register(Case)
admin.site.register(Location)
admin.site.register(Patient)
admin.site.register(Infecting_Virus)
admin.site.register(VisitDetail)
